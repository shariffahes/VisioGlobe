/*
 * Copyright (c) Visioglobe SAS. All rights reserved.
 *
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */



#define VME_DEPRECATED __attribute__((deprecated))
#define VME_DEPRECATED_MSG(_msg) __attribute__((deprecated(_msg)));

